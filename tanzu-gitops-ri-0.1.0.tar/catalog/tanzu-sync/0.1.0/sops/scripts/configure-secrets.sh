#!/usr/bin/env bash
./tanzu-sync/scripts/sensitive-values.sh
